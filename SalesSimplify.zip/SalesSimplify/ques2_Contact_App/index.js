import express from "express";
import contactRoutes from "./routes/contact.js"

const app=express() ;

// middlewares 

// to parse the req body
app.use( express.json() ); 

// common route for all contact api
app.use( '/contact' , contactRoutes )

// default route
app.use( '*' , ( req , res )=>{
    res.status( 404 ).json( "Invalid Endpoint 🤯") ;
})


// server on port
app.listen( 8080 , ()=>{
    console.log("Listning at port 8080...");
})