import contactDB from "../models/contactDB.json" assert { type: "json" };
import fs from "fs";
import { validate } from "./validate.js";

// getContactById function will find record with the passed id 
// if record exist return will return it
// else sent the error msg
export const getContactById = (id) => {
    const result = contactDB.find(elt => elt.id === id)
    if (result) {
        return {
            flag: 'true',
            data: result,
            status: 200,
        }
    }
    else {
        return {
            flag: 'false',
            data: '',
            status: 404,
        }
    }
}

// checkForDuplicate is a helper function
// this function will check if there any record in db with the passed email & phone combination and return true / false based on that
const checkForDuplicate = (phone, email) => {
    const result = contactDB.find(elt => (elt.phone === phone && elt.email === email))
    // the email and phone already exist
    if (result) {
        return true;
    }
    // not exist
    return false;
}


// updateDB function is helper function
// fnction is used to write change back to json DB
const updateDB = (dbData) => {
    fs.writeFile('./models/contactDB.json', JSON.stringify(dbData), err => {
        if (err) {
            return {
                flg: false,
                msg: "Internal Server Error 🤯🤯",
                status: 500,
            }
        }
    })
}

// doubt -- id will be assigned by us only then no need to check it i guess
// export const validateID=( id )=>{
//     const result=contactDB.find( elt => elt.id===id );
//     if( result ) return true ; // the Id already exist
//     else return false ;
// }

// addNewContact function will add new record to the json DB after validating the inputs 
export const addNewContact = (contactData) => {

    // validate the input data 
    const response = validate(contactData);
    if (!response.flg) return response;
    else if (checkForDuplicate(contactData.phone, contactData.email)) {
        return {
            flg: false,
            msg: `Contact already exist with phone:: ${contactData.phone} && email:: ${contactData.email}`,
            status: 403, // resource already exixt
        }
    }

    // change the country to upper case
    contactData.address.country = contactData.address.country.toUpperCase();

    // assign the id to this new contact record 
    // contactData.id = (contactDB.length + 1)+'';
    contactData.id = Date.now() + '';

    // adding new record in json db
    contactDB.push(contactData);

    //update db with new record
    const result = updateDB(contactDB);

    // if result is undefined means no error , means record created successfully
    if (!result) {
        return {
            flg: true,
            msg: "New contact created successfully",
            status: 201,
        }
    }
    // means there is some error
    return result;
}

// deleteContactById function will delete a contact record by id
export const deleteContactById = (id) => {
    for (var itr = 0; itr < contactDB.length; itr++) {
        console.log("--> ", contactDB[itr].id)
        if (contactDB[itr].id === id) {
            contactDB.splice(itr, 1);
            const result = updateDB(contactDB);
            // if result is undefined means no error , means record created successfully
            if (!result) {
                return {
                    flg: true,
                    msg: `Contact record with id:${id} has been deleted successfully`,
                    status: 200,
                }
            }
            // means there is some error
            return result;
        }
    }
    // if there is no record with given id 
    return {
        msg: `N0 Contact record found with id:${id} `,
        status: 400,
    };
}

// updateContactById function will update an existing record 
export const updateContactById = (id, body) => {
    for (var itr = 0; itr < contactDB.length; itr++) {
        if (contactDB[itr].id === id) {

            // validate the input data 
            const response = validate(body);
            if (!response.flg) return response;

            // if there is change in email and phone then we have to make sure that this changed phone&email combination should not exist in db 
            if (contactDB[itr].email != body.email || contactDB[itr].phone != body.phone) {
                if (checkForDuplicate(body.phone, body.email)) {
                    return {
                        msg: `Contact already exist with phone:: ${body.phone} && email:: ${body.email}`,
                        status: 403, 
                    }
                }
            }

            // if no change in email & phone and valid inputs , we can update the record
            contactDB[itr].firstName = body.firstName;
            contactDB[itr].lastName = body.lastName;
            contactDB[itr].gender = body.gender;
            contactDB[itr].email = body.email;
            contactDB[itr].phone = body.phone;
            contactDB[itr].address.line1 = body.address.line1;
            contactDB[itr].address.line2 = body.address.line2;
            contactDB[itr].address.country = body.address.country;
            contactDB[itr].address.city = body.address.city;
            contactDB[itr].address.zipCode = body.address.zipCode;


            const result = updateDB(contactDB);
            // if result is undefined means no error , means record created successfully
            if (!result) {
                return {
                    msg: `Contact record for id:: ${id} has been updated successfully`,
                    status: 202,
                }
            }
            // means there is some error
            return result;
        }
    }
}

