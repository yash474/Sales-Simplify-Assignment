// function to add 2 numbers 
const add_2_Nums=( num1 , num2 )=>{
    // validating the input 
    if( isNaN(num1) || isNaN(num2) ){
        console.log("Error : the parameter value is not a number");
        return new Error("Error : the parameter value is not a number") ;
    }
    // return the sum
    return num1+num2 ;
}

// calling 
const res=add_2_Nums( 30 , 20 ) ;
