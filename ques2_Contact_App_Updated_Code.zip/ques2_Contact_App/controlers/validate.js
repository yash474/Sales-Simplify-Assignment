
// {
    //     "id": "Mandatory, Unique, Any format eg. Alphnumeric, Number, UUID etc.",
    //     "firstName": "Mandatory, Only Alphabets, Min. Length 3",
    //     "lastName": "Mandatory, Only Alphabets, Min. Length 3",
    //     "gender": "Mandatory, Only (MALE or FEMALE or OTHERS)",
    //     "address": {
    //         "line1": "Mandatory, Any String/Symbol/Characters, Min. Length 8",
    //         "line2": "Optional, Any String/Symbol/Characters, any length",
    //         "city": "Mandatory, String/Symbol/Characters, any length",
    //         "country": "Mandatory, Any String/Symbol/Characters, any length, all caps",
    //         "zipCode": "Mandatory, Any String/Symbol/Characters, Max length 10"
    //     },
    //     "email": "Mandatory, valid email eg. any_valid@email.format",
    //     "phone": "Mandatory, only numbers, eg. 1234567890",
    //     "other": "Feel free to add other prop, if you want. However, it's not mandatory"
    // },
export const validate=( data )=>{
    if( data.firstName.length<3 || data.lastName.length<3 ){
        return{
            flg:false,
            msg:"first and last name should be at least 3 character" ,
            status:400,
        }
    }
    else if( data.gender!="MALE" && data.gender!="FEMALE" && data.gender!="OTHERS"){
        return{
            flg:false,
            msg:"Gender can be Only MALE or FEMALE or OTHERS" ,
            status:400,
        }
    }
    else if( data.address.line1.length<8 ){
        return{
            flg:false,
            msg:"Address line 1 should be atleast 8 length" ,
            status:400,
        }
    }
    else if( data.address.zipCode.length>10 ){
        return{
            flg:false,
            msg:"zipCode should be max 10 length" ,
            status:400,
        }
    }
    else if( data.phone.length!=10 ){
        return{
            flg:false,
            msg:"Phone no should be exactly 10 dighits" ,
            status:400,
        }
    }
    else if( data.email.length==0 ){
        return{
            flg:false,
            msg:"Email is required" ,
            status:400,
        }
    }    
    else return { 
        flg:true,
        msg:"input validated successfully",
        status:200,
    }
    
}