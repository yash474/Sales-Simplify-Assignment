import express from "express";
import contactDB from "../models/contactDB.json" assert { type: "json" };
import { getContactById , addNewContact , deleteContactById , updateContactById } from "../controlers/dbOpperations.js";

const router=express.Router() ;

// get all contacts from DB
router.get('/' , ( req , res)=>{
    const data=contactDB ;
    res.status(200).json({
        total_record:data.length ,
        records:data ,
    });
})

// get contact by id
router.get('/:id' , ( req , res )=>{
    const id=req.params.id ;
    const result=getContactById( id );
    if( result.flag ){
        res.status(result.status).json( result.data );
    }
    else{
        res.status(result.status).json( `No Contact found with id : ${id}` );
    }
})

// add new contact record
router.post( '/' , ( req , res )=>{
    const newData=req.body ;
    const result=addNewContact( newData );
    res.status(result.status).json(result.msg);
})

// delete contact by id
router.delete( '/:id' , ( req , res )=>{
    const id=req.params.id ;
    const result=deleteContactById( id );
    res.status( result.status).json( result.msg );
})

// update/edit a record 
router.put( '/:id' , ( req , res )=>{
    const id=req.params.id ;
    const body=req.body ;
    const result=updateContactById( id , body );
    res.status( result.status).json( result.msg );
})



export default router ;

